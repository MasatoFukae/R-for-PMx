# シャープ以降は読み込まれません。

x <- c(2, 4, 6)
y <- c(1, 2, 3)
data <- data.frame(x,y) # データフレーム作成
plot(data) # 散布図を作成
